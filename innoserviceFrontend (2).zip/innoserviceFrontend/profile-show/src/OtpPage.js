import React, { useState } from "react";
import Card from "@mui/material/Card";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import CardContent from "@mui/material/CardContent";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";

function OtpPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [otp, setOTP] = useState(Array(6).fill(""));

  const validateEmail = (input) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailRegex.test(input)) {
      setError("");
    } else {
      setError("Please enter a valid email address");
    }
  };

  const handleChangeEmail = (event) => {
    const inputValue = event.target.value;
    setEmail(inputValue);
    validateEmail(inputValue);
  };

  const handleChangeOTP = (index, value) => {
    const newOTP = [...otp];
    newOTP[index] = value;
    setOTP(newOTP);
  };

  const handleVerifyOTP = () => {
    // Implement your OTP verification logic here
    console.log("Verifying OTP:", otp.join(""));
  };

  const handleclick = async () => {
    if (!email || !otp) {
      alert("Please enter valid email and password");
      return;
    }

    try {
      const response = await axios.get("http://localhost:4000/validateOtp", {
        params: {
          email: email,
          otp: otp,
        },
      });

      if (response.data) {
        localStorage.setItem("token", response.data.token);
        navigate("/profile");
      }
    } catch (error) {
      if (error.response) {
        // The request was made and the server responded with a status code
        console.error("Server responded with status:", error.response.status);
        console.error("Response data:", error.response.data);
      }
    }
  };

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: "60vh",
      }}
    >
      <Card
        sx={{
          width: "40%",
          color: "black",
          textAlign: "center",
          justifyContent: "Center",
          height: "80%",
        }}
      >
        <CardContent>
          <Typography sx={{ color: "black", fontSize: "40px" }}>
            OTP Validate
          </Typography>
          <TextField
            id="outlined-basic"
            label="Email"
            variant="outlined"
            sx={{ width: "70%" }}
            onChange={handleChangeEmail}
            value={email}
          />
          {error && (
            <p style={{ color: "red", margin: "0", paddingTop: "8px" }}>
              {error}
            </p>
          )}
        </CardContent>
        <CardContent>
          <Grid container spacing={2} justifyContent="center">
            {otp.map((value, index) => (
              <Grid item key={index}>
                <TextField
                  variant="outlined"
                  size="small"
                  value={value}
                  onChange={(e) => handleChangeOTP(index, e.target.value)}
                  inputProps={{
                    maxLength: 1,
                    style: { width: "1.5em", textAlign: "center" },
                  }}
                />
              </Grid>
            ))}
          </Grid>
          <Button
            variant="contained"
            sx={{ marginTop: 3 }}
            onClick={handleclick}
          >
            Verify OTP
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

export default OtpPage;
