import React, { useState } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Profile() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [bio, setBio] = useState("");

  const handleSaveProfile = async () => {
    if (!name || !phone || !bio) {
      console.log("name,phone,bio is not their");
      alert("please fill the required filled");
      return;
    }
    try {
      const headers = {
        "Content-Type": "application/json",
        "x-auth-token": localStorage.getItem("token"), // Assuming your backend expects the token in a header named "x-auth-token"
      };
      const response = await axios.patch(
        "http://localhost:4000/editProfile",
        {
          name,
          phone,
          bio,
        },
        {
          headers: headers,
        }
      );

      if (response.data) {
        alert("User data edited Successfully");
      }
    } catch (e) {
      console.log(e);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div style={{ padding: "20px" }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h5" gutterBottom>
                Edit Profile
              </Typography>
              <TextField
                label="Name"
                variant="outlined"
                sx={{ marginTop: 3 }}
                fullWidth
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <TextField
                label="Email"
                variant="outlined"
                sx={{ marginTop: 3 }}
                fullWidth
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <TextField
                label="Phone"
                variant="outlined"
                sx={{ marginTop: 3 }}
                fullWidth
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
              <TextField
                label="Bio"
                variant="outlined"
                sx={{ marginTop: 3 }}
                fullWidth
                multiline
                rows={4}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
              />
              <Button
                variant="contained"
                color="primary"
                onClick={handleSaveProfile}
                style={{ marginTop: "20px" }}
              >
                Save Profile
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={handleLogout}
                style={{ marginTop: "20px", marginLeft: "1150px" }}
              >
                Logout
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </div>
  );
}

export default Profile;
