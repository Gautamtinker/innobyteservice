import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  BrowserRouter,
} from "react-router-dom";
import { styled } from "@mui/system";
import Signup from "./Signup";
import Login from "./Login";
import OtpPage from "./OtpPage";
import Profile from "./Profile";
import { decodeJwt } from "./utility/CommanFunction";
import { useEffect } from "react";

const MyComponent = styled("div")({
  backgroundColor: "#14161a",
  color: "white",
  minHeight: "100vh",
});

function App() {
  const token = localStorage.getItem("token");
  const decodeToken = token ? decodeJwt(token) : null; // Handle case when token is null
  console.log(decodeToken);
  useEffect(() => {
    if (decodeToken && decodeToken.user.exp * 1000 < Date.now()) {
      localStorage.removeItem("token");
    }
  }, [token, decodeToken]); // Add decodeToken as a dependency

  return (
    <BrowserRouter>
      <MyComponent>
        <div>
          <Routes>
            <Route path="/Profile" element={<Profile />} />
            <Route
              path="/"
              element={
                decodeToken && decodeToken.user && decodeToken.user.id ? (
                  <Navigate to="/profile" replace />
                ) : (
                  <Login />
                )
              }
            />
            <Route
              path="/otp"
              element={
                decodeToken && decodeToken.user && decodeToken.user.id ? (
                  <Navigate to="/profile" replace />
                ) : (
                  <OtpPage />
                )
              }
            />
            <Route
              path="/Signup"
              element={
                decodeToken && decodeToken.user && decodeToken.user.id ? (
                  <Navigate to="/profile" replace />
                ) : (
                  <Signup />
                )
              }
            />
          </Routes>
        </div>
      </MyComponent>
    </BrowserRouter>
  );
}

export default App;
