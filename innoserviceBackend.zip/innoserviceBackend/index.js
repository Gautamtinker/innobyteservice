const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const dotenv = require("dotenv");
const connection = require("./utiles/db");
const UserRoute = require("./Route/UserRoute.js");
const app = express();
dotenv.config("");
app.use(express.json());
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
connection();
app.use("/", UserRoute);
const PORT = process.env.port;
app.listen(PORT, () => {
  console.log(`server is runing on ${PORT}`);
});
