const bcrypt = require("bcrypt");
const sendEmail = require("../utiles/sendEmail.js");
const p = require("../utiles/htmltemplate");
const User = require("../model/User.js");
const { jwtTokenMake } = require("../utiles/CommanFunction");
exports.SignUp = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res
        .status(400)
        .json({ message: "Please provide name,email, password" });
    }
    let user = await User.findOne({ email });

    if (user) {
      return res.status(400).json({ message: "User already exists" });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    user = new User({
      email,
      name,
      password: hashedPassword,
      otp,
    });
    await user.save();
    await sendEmail({ toemail: email, template: p }, name, otp);

    return res.status(200).json({ message: "User signed up successfully" });
  } catch (e) {
    console.error(e);
    res.status(500).send("Internal Server Error");
  }
};
exports.Login = async (req, res) => {
  try {
    const { email, password } = req.query;
    console.log(req);
    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "Please provide email, password" });
    }

    // Find the user by email
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    console.log(user);
    if (user.isVerified == false) {
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      user.otp = otp;
      await user.save();
      await sendEmail({ toemail: email, template: p }, user.name, otp);
    }
    // Generate JWT token
    const token = await jwtTokenMake(user);
    res.status(200).json({
      message: "Successfully Login",
      token,
      isVerified: user.isVerified,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ message: "Server Error" });
  }
};

exports.validateOtp = async (req, res) => {
  try {
    let { email, otp } = req.query;
    otp = otp.join("");
    if (!email || !otp) {
      return res.status(400).json({ message: "Please provide email, otp" });
    }

    // Find the user by email
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    // Generate JWT token
    if (otp !== user.otp) {
      return res.status(404).json({ message: "Otp is Not Valid" });
    }
    await User.updateOne(
      { email: email }, // Query to find the user by ID
      { $set: { isVerified: true } } // Update the isVerified field to true
    );
    const token = await jwtTokenMake(user);
    return res.status(200).json({ message: "Otp validate successfull", token });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ message: "Server Error" });
  }
};
exports.Profile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    res.status(200).json({ message: "Profile send", user });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ message: "Server Error" });
  }
};
exports.editProfile = async (req, res) => {
  try {
    const { id } = req.user;
    const { name, phone, bio } = req.body;
    console.log;
    if (!name || !phone || !bio) {
      return res.status(400).json({ message: "Please enter required field" });
    }
    await User.updateOne(
      {
        _id: id,
      }, // Query to find the user by ID
      { $set: { name: name, phone: phone, bio: bio } } // Update the isVerified field to true
    );
    res.status(200).json({ message: "Profile Successfully editable" });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ message: "Server Error" });
  }
};
