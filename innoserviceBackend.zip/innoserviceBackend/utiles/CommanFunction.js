const jwt = require("jsonwebtoken");
exports.replaceTemplate = (template, name, otp) => {
  console.log(name);
  let htmlContent = template.replace(/%%NAME%%/g, name);
  htmlContent = htmlContent.replace(/%%OTP%%/g, otp);
  return htmlContent;
};

exports.jwtTokenMake = async (user) => {
  return new Promise((resolve, reject) => {
    const payload = {
      user: {
        id: user._id,
      },
    };

    jwt.sign(payload, "secretkey", { expiresIn: "1h" }, (err, token) => {
      if (err) {
        reject(err);
      } else {
        resolve(token);
      }
    });
  });
};
