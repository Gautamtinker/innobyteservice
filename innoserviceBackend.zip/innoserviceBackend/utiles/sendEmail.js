const { request } = require("express");
const nodemailer = require("nodemailer");
const { replaceTemplate } = require("../utiles/CommanFunction.js");
// Send OTP to the user's email
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "Gautamtinker83@gmail.com",
    pass: "vfct paor gchu wkzl",
  },
});

const sendEmail = async (emailDetail, name, otp) => {
  console.log(emailDetail, name);
  const htmlTemplate = replaceTemplate(emailDetail.template.p, name, otp);
  const mailOptions = {
    from: "Gautamtinker83@gmail.com",
    to: emailDetail.toemail,
    subject: "Email Confirmation OTP",
    html: htmlTemplate,
  };
  await transporter.sendMail(mailOptions);
};
module.exports = sendEmail;
