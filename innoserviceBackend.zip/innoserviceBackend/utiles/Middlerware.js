const jwt = require("jsonwebtoken");
exports.authMiddleware = async (req, res, next) => {
  const token = req.header("x-auth-token");
  console.log(token);
  if (!token) {
    return res.status(401).json({ message: "No token, authorization denied" });
  }

  try {
    const decoded = jwt.verify(token, "secretkey");
    req.user = decoded.user;
    next();
  } catch (error) {
    console.error(error.message);
    res.status(401).json({ message: "Invalid token" });
  }
};
