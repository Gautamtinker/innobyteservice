const express = require("express");
const {
  SignUp,
  Login,
  validateOtp,
  Profile,
  editProfile,
} = require("../controller/UserController.js");
const { authMiddleware } = require("../utiles/Middlerware.js");
const router = express.Router();

router.post("/", SignUp);
router.get("/Login", Login);
router.get("/validateOtp", validateOtp);
router.get("/Profile", authMiddleware, Profile);
router.patch("/editProfile", authMiddleware, editProfile);

module.exports = router;
